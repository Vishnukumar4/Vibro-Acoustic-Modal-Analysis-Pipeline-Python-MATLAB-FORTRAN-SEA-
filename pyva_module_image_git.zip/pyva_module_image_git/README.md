# pyva Module Overview Image for GitHub

This folder contains the module overview image used in the Vibro-Acoustic Modal Analysis Pipeline README.

## File Structure

```text
project-root/
├── README.md
├── README_image_section.md
└── images/
    └── pyva_modules_overview.png
```

## Markdown to Insert in Main README

```markdown
## pyva Module Architecture

![Overview of pyva sub-packages and modules](images/pyva_modules_overview.png)
```

## Git Commands

```bash
git add images/pyva_modules_overview.png README.md
git commit -m "Add pyva module overview image"
git push
```
