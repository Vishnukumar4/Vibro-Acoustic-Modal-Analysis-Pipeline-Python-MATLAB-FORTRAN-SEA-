## pyva Module Architecture

The vibro-acoustic simulation pipeline is organized around the `pyva` toolbox structure. The top-level `models` module contains the main simulation model classes, while the supporting sub-packages handle systems, coupling, material properties, loads, data structures, geometry, and utility functions.

![Overview of pyva sub-packages and modules](images/pyva_modules_overview.png)

### Module Summary

| Package / Module | Purpose in Project |
|---|---|
| `pyva.models` | Main model layer for FEM, VAmodel, TMmodel, and HybridModel simulations. |
| `FEM` | Used for deterministic finite-element style modal representation of structural plates. |
| `VAmodel` | Used for deterministic vibro-acoustic matrix-based response modeling. |
| `TMmodel` | Used for transfer-matrix simulations of layered acoustic treatments. |
| `HybridModel` | Used for SEA and hybrid FEM/SEA model assembly. |
| `systems` | Defines acoustic rooms, plates, and dynamic subsystems. |
| `coupling` | Handles junctions and energy transfer between subsystems. |
| `properties` | Stores material and structural properties such as fluids, plates, foams, and poroelastic materials. |
| `loads` | Defines acoustic power, force excitation, and simulation load cases. |
| `data` | Handles matrices, vectors, signals, frequency axes, and degrees of freedom. |
| `geometry` | Supports geometry and mesh-related data. |
| `useful` | Contains helper utilities for plotting, frequency-band setup, and post-processing. |

